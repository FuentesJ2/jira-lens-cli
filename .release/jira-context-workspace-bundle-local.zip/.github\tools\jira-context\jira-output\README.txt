Use this folder for user-visible normalized JSON outputs when you want to persist CLI fetch results.
